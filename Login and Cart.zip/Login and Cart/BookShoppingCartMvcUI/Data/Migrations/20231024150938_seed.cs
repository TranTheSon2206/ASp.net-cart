﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookShoppingCartMvcUI.Data.Migrations
{
    /// <inheritdoc />
    public partial class seed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //Thêm loại (genre)
            migrationBuilder.InsertData(
            table: "Genre",
            columns: new[] { "GenreName" },
            values: new object[] { "Fantasy" }
            );

            migrationBuilder.InsertData(
                table: "Genre",
                columns: new[] { "GenreName" },
                values: new object[] { "Mystery" }
            );

            migrationBuilder.InsertData(
                table: "Genre",
                columns: new[] { "GenreName" },
                values: new object[] { "Science Fiction" }
            );

            migrationBuilder.InsertData(
                table: "Genre",
                columns: new[] { "GenreName" },
                values: new object[] { "Romance" }
            );

            //Thêm sách
            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "BookName", "AuthorName", "Price", "GenreId" },
                values: new object[] { "Book 1", "Author 1", 19.99, 1 }
            );

            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "BookName", "AuthorName", "Price", "GenreId" },
                values: new object[] { "Book 2", "Author 2", 24.99, 2 }
            );

            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "BookName", "AuthorName", "Price", "GenreId" },
                values: new object[] { "Book 3", "Author 3", 14.99, 3 }
            );

            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "BookName", "AuthorName", "Price", "GenreId" },
                values: new object[] { "Book 4", "Author 4", 29.99, 4 }
            );

            migrationBuilder.InsertData(
                table: "Book",
                columns: new[] { "BookName", "AuthorName", "Price", "GenreId" },
                values: new object[] { "Book 5", "Author 5", 22.99, 1 }
            );

            

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
